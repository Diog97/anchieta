﻿namespace Aula01
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numericValor1 = new System.Windows.Forms.NumericUpDown();
            this.numericValor2 = new System.Windows.Forms.NumericUpDown();
            this.numericValor3 = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericValor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericValor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericValor3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(131, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(223, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // numericValor1
            // 
            this.numericValor1.Location = new System.Drawing.Point(39, 30);
            this.numericValor1.Name = "numericValor1";
            this.numericValor1.Size = new System.Drawing.Size(67, 20);
            this.numericValor1.TabIndex = 3;
            // 
            // numericValor2
            // 
            this.numericValor2.Location = new System.Drawing.Point(134, 30);
            this.numericValor2.Name = "numericValor2";
            this.numericValor2.Size = new System.Drawing.Size(67, 20);
            this.numericValor2.TabIndex = 4;
            this.numericValor2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // numericValor3
            // 
            this.numericValor3.Location = new System.Drawing.Point(226, 30);
            this.numericValor3.Name = "numericValor3";
            this.numericValor3.Size = new System.Drawing.Size(67, 20);
            this.numericValor3.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(313, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numericValor3);
            this.Controls.Add(this.numericValor2);
            this.Controls.Add(this.numericValor1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.numericValor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericValor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericValor3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericValor1;
        private System.Windows.Forms.NumericUpDown numericValor2;
        private System.Windows.Forms.NumericUpDown numericValor3;
        private System.Windows.Forms.Button button1;
    }
}