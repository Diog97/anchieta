﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula01
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }
        int valor1 = 0;
        int valor2 = 0;
        int valor3 = 0;
        int resultado = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            valor1 = (int)numericValor1.Value;
            valor2 = (int)numericValor2.Value;
            valor3 = (int)numericValor3.Value;

            resultado = (valor1 + valor2) * valor3;

            MessageBox.Show("O Resulta é: " + resultado.ToString() + " ;)");
        }
    }
}
