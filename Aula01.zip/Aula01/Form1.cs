﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula01
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        int valor1 = 0;
        int valor2 = 0;
        int resultado = 0;

        private void Principal_Load(object sender, EventArgs e)
        {

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            valor1 = (int)numericValor1.Value;
            valor2 = (int)numericValor2.Value;

            resultado = valor1 + valor2;

            lblResultado.Text = "O Resulta é: " + resultado.ToString() + " ;)"; resultado.ToString();
            LimparTela();
            //MessageBox.Show("O Resulta é: " + resultado.ToString() + " ;)");
        }

        private void LimparTela()
        {
            numericValor1.Value = 0;
            numericValor2.Value = 0;
        }

        private void numericValor1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.ShowDialog();
        }
    }
}
