﻿namespace Trabalho
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPlayer = new System.Windows.Forms.Label();
            this.lblRodadas = new System.Windows.Forms.Label();
            this.lblCpu = new System.Windows.Forms.Label();
            this.lblEmpates = new System.Windows.Forms.Label();
            this.pb0 = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb3 = new System.Windows.Forms.PictureBox();
            this.pb4 = new System.Windows.Forms.PictureBox();
            this.pb5 = new System.Windows.Forms.PictureBox();
            this.pb6 = new System.Windows.Forms.PictureBox();
            this.pb7 = new System.Windows.Forms.PictureBox();
            this.pb8 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPlayer
            // 
            this.lblPlayer.AutoSize = true;
            this.lblPlayer.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblPlayer.Location = new System.Drawing.Point(787, 115);
            this.lblPlayer.Name = "lblPlayer";
            this.lblPlayer.Size = new System.Drawing.Size(44, 16);
            this.lblPlayer.TabIndex = 0;
            this.lblPlayer.Text = "label1";
            // 
            // lblRodadas
            // 
            this.lblRodadas.AutoSize = true;
            this.lblRodadas.BackColor = System.Drawing.Color.Transparent;
            this.lblRodadas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblRodadas.Location = new System.Drawing.Point(56, 279);
            this.lblRodadas.Name = "lblRodadas";
            this.lblRodadas.Size = new System.Drawing.Size(44, 16);
            this.lblRodadas.TabIndex = 1;
            this.lblRodadas.Text = "label1";
            this.lblRodadas.Click += new System.EventHandler(this.lblRodadas_Click);
            // 
            // lblCpu
            // 
            this.lblCpu.AutoSize = true;
            this.lblCpu.BackColor = System.Drawing.Color.Transparent;
            this.lblCpu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblCpu.Location = new System.Drawing.Point(787, 444);
            this.lblCpu.Name = "lblCpu";
            this.lblCpu.Size = new System.Drawing.Size(44, 16);
            this.lblCpu.TabIndex = 2;
            this.lblCpu.Text = "label1";
            // 
            // lblEmpates
            // 
            this.lblEmpates.AutoSize = true;
            this.lblEmpates.BackColor = System.Drawing.Color.Transparent;
            this.lblEmpates.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblEmpates.Location = new System.Drawing.Point(787, 279);
            this.lblEmpates.Name = "lblEmpates";
            this.lblEmpates.Size = new System.Drawing.Size(44, 16);
            this.lblEmpates.TabIndex = 13;
            this.lblEmpates.Text = "label1";
            // 
            // pb0
            // 
            this.pb0.BackColor = System.Drawing.Color.Transparent;
            this.pb0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb0.Location = new System.Drawing.Point(212, 48);
            this.pb0.Name = "pb0";
            this.pb0.Size = new System.Drawing.Size(160, 160);
            this.pb0.TabIndex = 14;
            this.pb0.TabStop = false;
            this.pb0.Tag = "0";
            this.pb0.Click += new System.EventHandler(this.pb_Click);
            // 
            // pb1
            // 
            this.pb1.BackColor = System.Drawing.Color.Transparent;
            this.pb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb1.Location = new System.Drawing.Point(378, 48);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(160, 160);
            this.pb1.TabIndex = 15;
            this.pb1.TabStop = false;
            this.pb1.Tag = "1";
            this.pb1.Click += new System.EventHandler(this.pb_Click);
            // 
            // pb2
            // 
            this.pb2.BackColor = System.Drawing.Color.Transparent;
            this.pb2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb2.Location = new System.Drawing.Point(544, 48);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(160, 160);
            this.pb2.TabIndex = 16;
            this.pb2.TabStop = false;
            this.pb2.Tag = "2";
            this.pb2.Click += new System.EventHandler(this.pb_Click);
            // 
            // pb3
            // 
            this.pb3.BackColor = System.Drawing.Color.Transparent;
            this.pb3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb3.Location = new System.Drawing.Point(212, 214);
            this.pb3.Name = "pb3";
            this.pb3.Size = new System.Drawing.Size(160, 160);
            this.pb3.TabIndex = 17;
            this.pb3.TabStop = false;
            this.pb3.Tag = "3";
            this.pb3.Click += new System.EventHandler(this.pb_Click);
            // 
            // pb4
            // 
            this.pb4.BackColor = System.Drawing.Color.Transparent;
            this.pb4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb4.Location = new System.Drawing.Point(378, 214);
            this.pb4.Name = "pb4";
            this.pb4.Size = new System.Drawing.Size(160, 160);
            this.pb4.TabIndex = 18;
            this.pb4.TabStop = false;
            this.pb4.Tag = "4";
            this.pb4.Click += new System.EventHandler(this.pb_Click);
            // 
            // pb5
            // 
            this.pb5.BackColor = System.Drawing.Color.Transparent;
            this.pb5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb5.Location = new System.Drawing.Point(544, 214);
            this.pb5.Name = "pb5";
            this.pb5.Size = new System.Drawing.Size(160, 160);
            this.pb5.TabIndex = 19;
            this.pb5.TabStop = false;
            this.pb5.Tag = "5";
            this.pb5.Click += new System.EventHandler(this.pb_Click);
            // 
            // pb6
            // 
            this.pb6.BackColor = System.Drawing.Color.Transparent;
            this.pb6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb6.Location = new System.Drawing.Point(212, 380);
            this.pb6.Name = "pb6";
            this.pb6.Size = new System.Drawing.Size(160, 160);
            this.pb6.TabIndex = 20;
            this.pb6.TabStop = false;
            this.pb6.Tag = "6";
            this.pb6.Click += new System.EventHandler(this.pb_Click);
            // 
            // pb7
            // 
            this.pb7.BackColor = System.Drawing.Color.Transparent;
            this.pb7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb7.Location = new System.Drawing.Point(378, 380);
            this.pb7.Name = "pb7";
            this.pb7.Size = new System.Drawing.Size(160, 160);
            this.pb7.TabIndex = 21;
            this.pb7.TabStop = false;
            this.pb7.Tag = "7";
            this.pb7.Click += new System.EventHandler(this.pb_Click);
            // 
            // pb8
            // 
            this.pb8.BackColor = System.Drawing.Color.Transparent;
            this.pb8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb8.Location = new System.Drawing.Point(544, 380);
            this.pb8.Name = "pb8";
            this.pb8.Size = new System.Drawing.Size(160, 160);
            this.pb8.TabIndex = 22;
            this.pb8.TabStop = false;
            this.pb8.Tag = "8";
            this.pb8.Click += new System.EventHandler(this.pb_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Trabalho.Properties.Resources.jvbackground2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(930, 575);
            this.Controls.Add(this.pb8);
            this.Controls.Add(this.pb7);
            this.Controls.Add(this.pb6);
            this.Controls.Add(this.pb5);
            this.Controls.Add(this.pb4);
            this.Controls.Add(this.pb3);
            this.Controls.Add(this.pb2);
            this.Controls.Add(this.pb1);
            this.Controls.Add(this.pb0);
            this.Controls.Add(this.lblEmpates);
            this.Controls.Add(this.lblCpu);
            this.Controls.Add(this.lblRodadas);
            this.Controls.Add(this.lblPlayer);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPlayer;
        private System.Windows.Forms.Label lblRodadas;
        private System.Windows.Forms.Label lblCpu;
        private System.Windows.Forms.Label lblEmpates;
        private System.Windows.Forms.PictureBox pb0;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.PictureBox pb2;
        private System.Windows.Forms.PictureBox pb3;
        private System.Windows.Forms.PictureBox pb4;
        private System.Windows.Forms.PictureBox pb5;
        private System.Windows.Forms.PictureBox pb6;
        private System.Windows.Forms.PictureBox pb7;
        private System.Windows.Forms.PictureBox pb8;
    }
}

