﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO
{
    public class Inventario
    {
        private List<Item> itens = new List<Item>();
        public List<Item> Itens => itens;

        public void AdicionarItem(Item item)
        {
            itens.Add(item);
            Console.WriteLine($"{item.Nome} adicionado ao inventário.");
        }

        public void RemoverItem(Item item)
        {
            if (itens.Contains(item))
            {
                itens.Remove(item);
                Console.WriteLine($"{item.Nome} removido do inventário.");
            }
            else
            {
                Console.WriteLine("Item não encontrado no inventário.");
            }
        }

        public void MostrarInventario()
        {
            Console.WriteLine("Inventário:");
            foreach (var item in itens)
            {
                Console.WriteLine(item.Descricao());
            }
        }

        public void UsarItem(Item item)
        {
            if (itens.Contains(item))
            {
                item.Usar();
            }
            else
            {
                Console.WriteLine("Item não encontrado no inventário.");
            }
        }

        internal void AdicionarItem()
        {
            throw new NotImplementedException();
        }
    }
}
