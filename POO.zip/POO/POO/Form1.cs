﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POO
{
    public partial class Form1 : Form
    {

        private Inventario inventario = new Inventario();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dgitens.AutoGenerateColumns = true;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            inventario.AdicionarItem();
            dgitens.DataSource = null;
            dgitens.DataSource = inventario.Itens;
            dgitens.Refresh();
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            if (dgitens.SelectedRows.Count > 0)
            {
                var itemSelecionado = dgitens.SelectedRows[0].DataBoundItem as Item;
                inventario.RemoverItem(itemSelecionado);
                dgitens.DataSource = null;
                dgitens.DataSource = inventario.Itens;
                dgitens.Refresh();
            }
        }

        private void btnUsar_Click(object sender, EventArgs e)
        {
            if (dgitens.SelectedRows.Count > 0)
            {
                var itemSelecionado = dgitens.SelectedRows[0].DataBoundItem as Item;
                inventario.UsarItem(itemSelecionado);
            }
        }
    }
}
