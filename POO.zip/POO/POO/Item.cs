﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO
{
    public class Item
    {
        public string Nome { get; set; }
        public double Peso { get; set; }
        public double Valor { get; set; }

        public virtual void Usar()
        {
            Console.WriteLine("Item usado");
        }
        public virtual string Descricao()
        {
            return $"{Nome} (Peso: {Peso}, Valor: {Valor})";
        }
    }

    public class Arma : Item
    {
        private string v1;
        private double v2;
        private int v3;
        private int v4;

        public Arma(string v1, double v2, int v3, int v4)
        {
            this.v1 = v1;
            this.v2 = v2;
            this.v3 = v3;
            this.v4 = v4;
        }

        public double Dano { get; set; }

        public override void Usar()
        {
            Console.WriteLine($"{Dano} pontos de dano causado");
        }

        public override string Descricao()
        {
            return $"{base.Descricao()}, Dano: {Dano}";
        }
    }

    public class Pocao : Item
    {
        public double Cura { get; set; }

        public override void Usar()
        {
            Console.WriteLine($"{Cura} pontos de saúde curado");
        }
        public override string Descricao()
        {
            return $"{base.Descricao()}, Cura: {Cura}";
        }
    }

    public class Armadura : Item
    {
        public double Resistencia { get; set; }

        public override void Usar()
        {
            Console.WriteLine($"{Resistencia} pontos de resistencia aumentado");
        }
        public override string Descricao()
        {
            return $"{base.Descricao()}, Dano: {Resistencia}";
        }
    }
}
